# Changelog

## 1.5.0
- **Entende muito mais**: 102 jeitos comuns de falar viraram teste fixo ("bora", "cola em mim",
  "corre aqui", "fica de guarda", "faz o que quiser", "o que vc tem", "quero comida"...).
  "Para" sozinho para; "carne"/"comida" sempre é pra você (a não ser "come você").
- **Comida chega na sua mão**: o DR-0N abate o bicho de longe e agora **desce e recolhe a carne**
  (antes deixava no chão); a coleta de itens ignora o que ela mesma te entregou e pega pelo ponto
  do item se ele escorregar. Se não conseguir comida, ela avisa em vez de ficar quieta.
- **Construção muito mais rápida**:
  - materiais flexíveis: parede/chão aceitam qualquer tábua, pedra ou tronco que ela tiver
    (tronco = 4 tábuas); onde o chão já é firme ela aproveita o terreno;
  - vidro e tocha não travam mais a obra (janela fica aberta; tocha só se tiver carvão);
  - plantação começa com até 8 sementes e **não exige balde** (sem balde usa terra arada molhada);
  - fundação com terra em vez de minerar pedra; colocar bloco 2× mais rápido; alcança mais longe;
    obra em zigue-zague (anda menos); se faltar bloco no fim, busca e completa os buracos.
  - quebra blocos mais rápido (Lila 2,6× · DR-0N 5× o ritmo de um jogador sem efeito).
- **Modo torreta de verdade**: o DR-0N pousa suave até encostar no chão, encaixa no bloco e **se
  transforma** — tripé desce e crava no chão, braços e hélices recolhem, abre escudo frontal,
  canhão duplo sobe e o olho fica vermelho (transição animada). Pernas travadas: se empurrarem,
  volta pro lugar. Ao sair, desmonta e decola.

## 1.4.0
- **Novo companheiro: DR-0N**, drone-robô grande com controle próprio (ferro, vidro, redstone e
  diamante). Mesmo cérebro da Lila (planeja, coleta, minera, fabrica, constrói, planta), porém
  voa (motor de voo: direto, por cima de obstáculos ou por terra), é ~2× mais rápido, minera 2×
  mais rápido, enxerga mais longe, tem 160 de vida e inventário de 54 espaços.
- **Metralhadora e modo torreta** (pousa, trava as pernas e metralha monstros num raio grande).
- **Carona**: suba nele (toque de mão vazia ou "me dá carona"); você pilota olhando e andando,
  pular sobe; agachar desce e ele volta ao que estava fazendo. Atira em monstros durante o voo.
- **Escaneamento** do dono, **memórias** (diário + lugares lembrados) e **missões** com progresso.
- **"Cancelar tarefas"** no topo do menu dos dois controles.
- `/drone <ordem>`; HUD mostra os dois na mesma linha; Lila e DR-0N podem estar juntos.

## 1.3.0
- **Seguir como um mob de verdade**: ela é ligada ao dono (`tame`) e usa a IA nativa do jogo
  (`follow_owner`) para te acompanhar — pula degraus, nada, abre portas e contorna sozinha.
  Se empacar, o motor próprio assume por um trecho. Subir ladeira de degraus: 15 ticks no teste.
- **Motor próprio mais suave**: degrau de 1 bloco vira um pulinho em arco (não fica batendo na
  quina), não freia no centro de cada bloco em linha reta, resgate de travamento 2× mais rápido.
- **Perto primeiro, longe só se precisar**: olha em volta (10 → 24 blocos) antes de usar a
  memória; enxerga recursos expostos até 40 blocos; volta a lugares onde já viu o recurso;
  explora em anéis crescentes (18 → 68 blocos) em vez de sair andando longe direto.
- Mais "amiga": olha mais pra você quando está perto e acena se você agachar olhando pra ela.

## 1.2.0
- **Animações voltaram**: o efeito de partícula da animação de invocar estava em formato de lista;
  o jogo exige linha do tempo (`{"0.0": ...}`) e por causa disso rejeitava o arquivo de animações
  inteiro — ela ficava dura e a pálpebra do piscar cobria os olhos (rosto "bugado").
  O validador agora confere o formato de cada campo de animação/controlador.
- **Rosto**: a pálpebra fica escondida dentro da cabeça e só aparece quando pisca; tamanhos das
  peças em pixels inteiros (sem sangrar cor de outra parte da textura).
- **Comida muito mais rápida**: entrega o que já tem na hora; senão colhe maduro, caça os animais
  que estão perto e entrega (35 s no teste, antes 3 min); avisa no chat o que está fazendo.
- **Testes com jogador de verdade** (jogador simulado do GameTest, só no servidor de teste):
  seguir, "vem aqui", "pega madeira", "arranja comida", "faz uma picareta", "me dá tudo".

## 1.1.0
- **Corrigido o crash "exceção de vigia de script"**: a mineração profunda podia entrar num laço
  infinito quando a escadaria ficava cercada (blocos que ela não pode quebrar, lava, chunk não
  carregado). Agora todo laço cede pelo menos um tick e a escadaria desiste com segurança.
- **Menos engasgo**: orçamento de CPU por tick (A* fatiado por tempo, varreduras de blocos com
  limite e do centro para fora, obras grandes cedem o tick). Passo mais lento medido: 12 ms.
- **Movimento com física** (impulso, pulo nos degraus, nado) em vez de teleporte a cada tick:
  suave no celular e as animações de andar/correr também respondem à velocidade real.
- **Mais esperta**: vai junto quando você está viajando, trabalha por perto quando você para,
  fica com você nos primeiros 30 s, põe tochas quando você está no escuro, leva comida se você
  estiver com pouca vida, avisa o que vai fazer; reconhece mais blocos naturais (raízes,
  musgo pálido, azaleia, nylium...). Distância padrão para explorar sozinha: 64 blocos.
- Avisos no log limitados a 1 a cada 30 s por área (não enchem a tela).

## 1.0.0
- Personagem original **Lila**: modelo humanoide (ossos padrão de jogador), cabelo volumoso em
  camadas com franja recortada, presilha de folha, vestido com saia em duas camadas; textura
  pixel art 2× com rosto desenhado à mão e piscar animado.
- Animações de jogadora: andar, correr, agachar, nadar, escalar, cair, minerar, cortar, cavar,
  colocar, atacar, comer, fabricar, plantar, acenar, pensar, comemorar, sentar, dormir, derrota,
  invocação; cabelo e saia com movimento secundário.
- **Controle da Lila** (item 3D, infinito) com receita de ferro ou cobre; menu com campo de texto
  e botões rápidos; `/lila <ordem>`.
- Cérebro: reconhecedor de intenções pt-BR, planejador por encadeamento para trás com receitas
  reais, bancada e fornalha de verdade, mineração por escadaria/túnel, construção por plantas,
  plantação, comida, proteção, sono, IA autônoma por utilidade.
- Derrota sem morte e retorno em 20 s com inventário e plano preservados; dispensar/invocar sem
  perdas (estruturas do mundo).
- HUD localizador (barra de ação + barra de localização nativa).
- Testes: unitários, validação de IDs, validação cruzada de pacotes, typecheck e autoteste no
  servidor oficial do Bedrock.
